<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="HopeOfTheAcientDefault" tilewidth="64" tileheight="64" tilecount="8" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="64" height="64" source="grass.png"/>
 </tile>
 <tile id="1">
  <image width="64" height="64" source="../../../../../Program Files (x86)/Steam/SteamApps/common/Kenney Game Assets/Assets/Art/RPG pack (230 assets)/PNG/rpgTile024.png"/>
 </tile>
 <tile id="2">
  <image width="64" height="64" source="../../../../../Program Files (x86)/Steam/SteamApps/common/Kenney Game Assets/Assets/Art/RPG pack (230 assets)/PNG/rpgTile029.png"/>
 </tile>
 <tile id="3">
  <image width="64" height="64" source="../../../../../Program Files (x86)/Steam/SteamApps/common/Kenney Game Assets/Assets/Art/RPG pack (230 assets)/PNG/rpgTile079.png"/>
 </tile>
 <tile id="4">
  <image width="64" height="64" source="../../../../../Program Files (x86)/Steam/SteamApps/common/Kenney Game Assets/Assets/Art/RPG pack (230 assets)/PNG/rpgTile141.png"/>
 </tile>
 <tile id="5">
  <image width="64" height="64" source="../../../../../Program Files (x86)/Steam/SteamApps/common/Kenney Game Assets/Assets/Art/RPG pack (230 assets)/PNG/rpgTile142.png"/>
 </tile>
 <tile id="6">
  <image width="64" height="64" source="../../../../../Program Files (x86)/Steam/SteamApps/common/Kenney Game Assets/Assets/Art/RPG pack (230 assets)/PNG/rpgTile051.png"/>
 </tile>
 <tile id="7">
  <image width="64" height="64" source="../../../../../Program Files (x86)/Steam/SteamApps/common/Kenney Game Assets/Assets/Art/RPG pack (230 assets)/PNG/rpgTile153.png"/>
 </tile>
</tileset>
